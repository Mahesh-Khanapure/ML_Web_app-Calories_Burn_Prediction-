from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__,static_url_path='/static')

# Load the machine learning model
model = pickle.load(open('CalBurn.pkl', 'rb'))
@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])

def predict():
    gender = str(request.form.get("1"))
    age = int(request.form.get("2"))
    height = float(request.form.get("3"))
    weight = float(request.form.get("4"))
    workout_duration = float(request.form.get("5"))
    heart_rate = float(request.form.get("6"))
    body_temperature = float(request.form.get("7"))

    # Create a feature vector from the user input
    user_input =[
       gender, age , height, weight, workout_duration, heart_rate, body_temperature
    ]
    prediction = model.predict(np.array(user_input).reshape(1, -1))
    prediction=str(prediction)
    print(prediction)

    return render_template("result.html", prediction=prediction,user_input=user_input)

    

if __name__ == "__main__":
    app.run(debug=True)

